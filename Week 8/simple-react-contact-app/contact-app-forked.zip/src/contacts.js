const contacts = [
  {
    id: 1,
    name: "Mike",
    imgURL:
      "https://i.insider.com/59ea18312f2d9229008b475d?width=600&format=jpeg&auto=webp",
    phone: "+123 456 789",
    email: "mike@hawkinshigh.com"
  },
  {
    id: 2,
    name: "Eleven",
    imgURL:
      "https://cdn.vox-cdn.com/thumbor/FIo4NvQ7cMICxfSuyHZAvXCtnxs=/1400x1400/filters:format(jpeg)/cdn.vox-cdn.com/uploads/chorus_asset/file/23577698/strangerthings1.jpg",
    phone: "unknown",
    email: "unknown"
  },
  {
    id: 3,
    name: "Dustin",
    imgURL:
      "https://static.onecms.io/wp-content/uploads/sites/13/2016/08/08/dustin.jpg",
    phone: "+918 372 574",
    email: "dustin@hawkinshigh.com"
  },
  {
    id: 4,
    name: "Lucas",
    imgURL:
      "https://assets.popbuzz.com/2017/45/lucas-stranger-things--1509974047-view-0.png",
    phone: "+918 372 574",
    email: "lucas@hawkinshigh.com"
  },
  {
    id: 5,
    name: "Max",
    imgURL:
      "https://cartermatt.com/wp-content/uploads/2022/07/Max-Stranger-Things.webp",
    phone: "+312 272 178",
    email: "max@hawkinshigh.com"
  }
];

export default contacts;
