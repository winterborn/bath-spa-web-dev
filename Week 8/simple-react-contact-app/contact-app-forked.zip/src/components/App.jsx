import React from "react";
import Card from "../components/Card";
import contacts from "../contacts";

function createCard(mycontact) {
  return (
    <Card
      key={mycontact.id}
      name={mycontact.name}
      img={mycontact.imgURL}
      tel={mycontact.phone}
      email={mycontact.email}
    />
  );
}

//CRUD -Create ,Read,Update,Delete

function App() {
  return (
    <div>
      <h1 className="heading">Hawkins High School Contact List:</h1>
      {contacts.map(createCard)}
    </div>
  );
}

export default App;
